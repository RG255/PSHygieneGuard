﻿<#
	Anti-pattern: an UNANCHORED drive-letter regex ('^([A-Za-z]):' with no trailing '$') also
	matches a folder mount path, so code that means "is this a drive-letter mount?" silently
	also matches things it should not.

	Compare against ..\Good\CorrectDriveLetterCheck.ps1
#>
Function Test-IsDriveLetterMount
{
	Param ([String]$MountPath)

	# 'C:\SomeFolder\Mount' matches this too - the intent was "starts AND ENDS with just a
	# drive letter", but there's no trailing anchor, so a folder path under that drive matches.
	return $MountPath -match '^[A-Za-z]:'
}
