﻿<#
	Anti-pattern: an empty catch block with no reason and no signal to the caller.
	PSHG-InvokeSilentFailureSweep flags this as AP7 (Empty catch blocks).

	Compare against:
	  ..\Good\CorrectEmptyCatch-Suppressed.ps1
	  ..\Good\CorrectEmptyCatch-InlineComment.ps1
	  ..\Good\CorrectEmptyCatch-ActuallyHandled.ps1
#>
Function Remove-TempFile
{
	Param ([String]$Path)

	Try
	{
		Remove-Item -Path $Path -Force -ErrorAction Stop
	}
	Catch
	{
		# Nothing here. Did it fail because the file was already gone (fine), because it was
		# locked by another process (not fine), or because of a permissions problem (not fine)?
		# The caller has no way to know - the failure is completely invisible.
	}
}
