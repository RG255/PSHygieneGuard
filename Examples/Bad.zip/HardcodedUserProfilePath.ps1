﻿<#
	Anti-pattern: a hardcoded C:\Users\<name>\ path. Only ever works for that ONE named user,
	on that ONE machine - breaks for every other user and every other machine.

	Compare against ..\Good\CorrectUserProfilePath.ps1
#>
Function Get-UserConfigPath
{
	return 'C:\Users\Alice\AppData\Roaming\MyApp\config.json'
}
