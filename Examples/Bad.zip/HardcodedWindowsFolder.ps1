﻿<#
	Anti-pattern: hardcoded C:\Windows\. Breaks on any machine where Windows isn't installed
	on the C: drive (uncommon but real - some enterprise imaging setups, multi-boot systems).

	Compare against ..\Good\CorrectWindowsFolderPath.ps1
#>
Function Get-System32Path
{
	return 'C:\Windows\System32'
}
