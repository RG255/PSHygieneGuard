﻿<#
	Anti-pattern: an If/ElseIf/While written inside plain parens (...) instead of the
	subexpression operator $(...). This is VALID SYNTAX - it parses as a call to a command
	literally named "If", so PSHG-TestScriptSyntax and PSScriptAnalyzer both stay silent.
	It only fails at RUNTIME with a misleading "The term 'If' is not recognized..." error.
	PSHG-TestBareKeywordCommand is the only checker that catches this.

	Compare against ..\Good\CorrectBareKeywordUsage.ps1
#>
Function Get-StatusLabel
{
	Param ([Bool]$IsHealthy)

	$Label = (If ($IsHealthy) { 'OK' } Else { 'FAILED' })
	return $Label
}
