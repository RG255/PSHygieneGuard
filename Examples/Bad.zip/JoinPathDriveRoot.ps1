﻿<#
	BAD: Join-Path on a drive root built from a variable.

	Join-Path resolves the drive of its -Path through PowerShell's provider system first, and THROWS
	"Cannot find drive. A drive with the name 'X' does not exist." when that drive is not a live PSDrive.
	That is exactly the case this kind of code exists for - a USB drive plugged in after the session
	started, an unmounted VHD, a letter this machine does not have - so it fails where it was meant to cope.

	Compare against ..\Good\CorrectJoinPathDriveRoot.ps1 (build the string with [System.IO.Path]::Combine).
#>
Function Get-BackupFolderPath
{
	Param ([String]$Letter, [String]$RelativePath)

	Join-Path -Path ('{0}:\' -f $Letter) -ChildPath $RelativePath
}

Function Get-PublicFolderOnDrive
{
	Param ([String]$Letter)

	Join-Path "${Letter}:\Users" 'Public'
}
