# Anti-pattern: missing BOM. Under Windows PowerShell 5.1, a file with no BOM is read as
# ANSI/Windows-1252, not UTF-8 - any non-ASCII character below is mis-decoded silently.
# PSHG-TestFileEncoding flags this; run it with -Fix to add the BOM in place.
#
# FRAGILE ON PURPOSE, MAINTAINER NOTE: this file must stay BOM-less to demonstrate the defect.
# A bulk `PSHG-TestFileEncoding -Fix` run scoped to the whole module tree (rather than scoped
# away from Examples\Bad\) will silently "fix" this file and defeat its purpose - confirmed
# live during this module's own build. If Tests\PSHygieneGuard.Tests.ps1 reports this file as
# already-compliant, it was fixed by accident; restore it to no-BOM before committing.
Write-Host 'This file is missing its BOM.'