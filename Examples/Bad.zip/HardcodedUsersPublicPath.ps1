﻿<#
	Anti-pattern: a hardcoded C:\Users\Public\ path. Breaks on any machine where Windows
	isn't on C:, even though every user profile lives under the same drive as Windows itself.

	Compare against ..\Good\CorrectUsersPublicPath.ps1
#>
Function Get-SharedDesktopPath
{
	return 'C:\Users\Public\Desktop'
}
