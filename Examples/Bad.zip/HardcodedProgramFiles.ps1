﻿<#
	Anti-pattern: hardcoded C:\Program Files\. Breaks under a 32-bit process on 64-bit
	Windows (where $env:ProgramFiles correctly resolves to the 32-bit folder for that
	process, but a hardcoded path does not), and on any machine where Windows isn't on C:.

	Compare against ..\Good\CorrectProgramFilesPath.ps1
#>
Function Get-ToolExePath
{
	return 'C:\Program Files\MyTool\tool.exe'
}
