﻿<#
	Anti-pattern: a hardcoded Windows special-folder path instead of the matching environment
	variable. Breaks the moment the system drive isn't C:, ProgramData is redirected, or (for
	Program Files specifically) the process is 32-bit on 64-bit Windows.

	Compare against ..\Good\CorrectEnvironmentVariablePath.ps1
#>
Function Get-AppConfigPath
{
	return 'C:\ProgramData\MyApp\config.json'
}
