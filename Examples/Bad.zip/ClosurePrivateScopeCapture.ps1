﻿<#
	Anti-pattern: a $Private:-prefixed variable referenced inside a .GetNewClosure()'d
	scriptblock, relying on being captured from the enclosing scope. Plain variables survive
	this capture correctly; $Private:-scoped ones do not - the reference silently resolves to
	nothing, with no error, no warning, at the point the closure eventually runs.

	Compare against ..\Good\CorrectClosureVariableCapture.ps1
#>
Function New-ClickHandler
{
	Param ([String]$Label)

	$Private:_message = 'Clicked: {0}' -f $Label

	# $Private:_message silently fails to resolve when this scriptblock actually runs later
	# (e.g. as a WPF button's Click handler) - the click handler prints nothing useful.
	return { Write-Host $Private:_message }.GetNewClosure()
}
