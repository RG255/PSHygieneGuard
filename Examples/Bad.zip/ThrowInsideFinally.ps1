﻿<#
	Anti-pattern: a throw statement inside a Finally block. Finally runs on EVERY exit path
	out of its Try - including an already-handled Catch that reported and returned cleanly,
	not just when an exception is still propagating. This throw re-raises unconditionally
	regardless of how the Try/Catch above it actually exited, turning an already-handled
	failure (or even a clean success) back into an uncaught exception. Parses cleanly, no
	PSScriptAnalyzer finding - only PSHG-TestFinallyThrow catches it.

	Compare against ..\Good\CorrectFinallyUsage.ps1
#>
Function Invoke-Cleanup
{
	Param ([String]$ResourceId)

	Try
	{
		Disconnect-Resource -Id $ResourceId
	}
	Catch
	{
		Write-Error ('Disconnect failed for [{0}]: {1}' -f $ResourceId, $_.Exception.Message)
		return
	}
	Finally
	{
		# Fires even on the clean "reported and returned" path above - this throw turns
		# that already-handled failure back into an uncaught exception.
		throw 'Cleanup finally block failed'
	}
}
