﻿<#
	Anti-pattern: hardcoded C:\Program Files (x86)\. On a 64-bit machine with no x86 install
	of the target (or a genuinely non-default install location), this silently points at a
	folder that doesn't exist.

	Compare against ..\Good\CorrectProgramFilesX86Path.ps1
#>
Function Get-LegacyToolExePath
{
	return 'C:\Program Files (x86)\LegacyTool\tool.exe'
}
